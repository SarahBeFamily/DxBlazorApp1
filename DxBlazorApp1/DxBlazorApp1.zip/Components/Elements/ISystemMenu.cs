﻿using DxBlazorApp1.Services;

namespace DxBlazorApp1.Components.Elements
{
	public interface ISystemMenu
	{
		public MenuItemGroup MenuItems { get; }
	}
}